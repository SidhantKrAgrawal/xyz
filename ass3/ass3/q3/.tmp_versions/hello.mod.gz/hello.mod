/home/nsingla/scratch_home/training/os_assign/ass3/q3/hello.ko
/home/nsingla/scratch_home/training/os_assign/ass3/q3/hello.o
